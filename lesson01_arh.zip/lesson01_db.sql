-- MySQL dump 10.13  Distrib 8.0.13, for Win64 (x86_64)
--
-- Host: localhost    Database: lesson01_db
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cities_tbl`
--

DROP TABLE IF EXISTS `cities_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `cities_tbl` (
  `city_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `city_name_fld` varchar(250) NOT NULL,
  `region_id` smallint(6) unsigned NOT NULL,
  `district_id` smallint(6) unsigned NOT NULL,
  PRIMARY KEY (`city_id`),
  KEY `fc_reg_idx` (`region_id`),
  KEY `fc_dist_idx` (`district_id`),
  CONSTRAINT `fc_reg` FOREIGN KEY (`region_id`) REFERENCES `region_tbl` (`region_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cities_tbl`
--

LOCK TABLES `cities_tbl` WRITE;
/*!40000 ALTER TABLE `cities_tbl` DISABLE KEYS */;
INSERT INTO `cities_tbl` VALUES (1,'Москва',1,0),(2,'Наро-Фоминск',1,0),(3,'Люберцы',1,0),(4,'Санкт-Петербург',3,0),(5,'Тосно',3,0),(6,'Екатеринбург',2,0),(7,'Тагил',2,0),(8,'Киев',4,0),(9,'Харьков',5,0),(10,'Запорожье',6,0),(11,'Палермо',9,0),(12,'Флоренция',7,0),(13,'Милан',8,0);
/*!40000 ALTER TABLE `cities_tbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries_tbl`
--

DROP TABLE IF EXISTS `countries_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `countries_tbl` (
  `country_id` smallint(5) unsigned NOT NULL,
  `country_name` varchar(250) NOT NULL,
  PRIMARY KEY (`country_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries_tbl`
--

LOCK TABLES `countries_tbl` WRITE;
/*!40000 ALTER TABLE `countries_tbl` DISABLE KEYS */;
INSERT INTO `countries_tbl` VALUES (1,'Россия'),(2,'Украина'),(3,'Италия');
/*!40000 ALTER TABLE `countries_tbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `districts_tbl`
--

DROP TABLE IF EXISTS `districts_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `districts_tbl` (
  `district_id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `district_name_fld` varchar(255) NOT NULL,
  `region_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`district_id`),
  KEY `fc_reg2_idx` (`region_id`),
  CONSTRAINT `fc_reg2` FOREIGN KEY (`region_id`) REFERENCES `region_tbl` (`region_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `districts_tbl`
--

LOCK TABLES `districts_tbl` WRITE;
/*!40000 ALTER TABLE `districts_tbl` DISABLE KEYS */;
INSERT INTO `districts_tbl` VALUES (1,'Наро-Фоминский р-н',1),(2,'Московский р-н',1),(3,'Люберецкий р-н',1),(4,'Тосненский р-н',3),(5,'Санкт-Петербургский р-н',3),(6,'Свердловский р-н',2),(7,'Тагильский р-н',2),(8,'Без района',1);
/*!40000 ALTER TABLE `districts_tbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `region_tbl`
--

DROP TABLE IF EXISTS `region_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `region_tbl` (
  `region_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `region_name_fld` varchar(250) NOT NULL,
  `country_id` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`region_id`),
  KEY `fc1_idx` (`country_id`),
  CONSTRAINT `fc1` FOREIGN KEY (`country_id`) REFERENCES `countries_tbl` (`country_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `region_tbl`
--

LOCK TABLES `region_tbl` WRITE;
/*!40000 ALTER TABLE `region_tbl` DISABLE KEYS */;
INSERT INTO `region_tbl` VALUES (1,'Московская область',1),(2,'Свердловская область',1),(3,'Ленинградская область',1),(4,'Киевская область',2),(5,'Харьковская область',2),(6,'Запорожская область',2),(7,'Тоскана',3),(8,'Ломбардия',3),(9,'Сицилия',3);
/*!40000 ALTER TABLE `region_tbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'lesson01_db'
--

--
-- Dumping routines for database 'lesson01_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-18  9:54:45
